import 'package:car_carousel/homepage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'dart:io';

void main() {
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.dumpErrorToConsole(details);
    if (kReleaseMode)
      exit(1);
  };
  runApp(
  MaterialApp(
    debugShowCheckedModeBanner: false,
    title: "TESLA",
    home: MyApp(),
  )
);
}
