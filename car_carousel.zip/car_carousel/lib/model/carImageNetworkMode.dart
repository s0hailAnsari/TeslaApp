import 'package:car_carousel/model/ImageNetwork.dart';

class CarImage {
  // final List


  // final ImageNetwork modelS2015Link;
  // final ImageNetwork modelS2016Link;
  // final ImageNetwork modelS2017Link;
  // final ImageNetwork modelS2018Link;
  // final ImageNetwork modelS2019Link;
  // final ImageNetwork model32017Link;
  // final ImageNetwork model32018Link;
  // final ImageNetwork model32019Link;
  // final ImageNetwork modelX2015Link;
  // final ImageNetwork modelX2016Link;
  // final ImageNetwork modelX2017Link;
  // final ImageNetwork modelX2018Link;
  // final ImageNetwork modelX2019Link;
  // final ImageNetwork roadster2019Link;
  // final ImageNetwork roadster2020Link;
  // final ImageNetwork cybertruckLink;

  final ImageNetwork y2008;
  final ImageNetwork y2009;
  final ImageNetwork y2010;
  final ImageNetwork y2011;
  final ImageNetwork y2015;
  final ImageNetwork y2016;
  final ImageNetwork y2017;
  final ImageNetwork y2018;
  final ImageNetwork y2019;
  final ImageNetwork y2020;

  // final String blackMS2015;
  // final String blueMetallicMS2015;
  // final String deepBlueMetallicMS2015;
  // final String greyMetallicMS2015;
  // final String midgnightSilverMS2015;
  // final String obsidianBlackMetallicMS2015;
  // final String pearlWhiteMulticoatMS2015;
  // final String redMulticoatMS2015;
  // final String silverMetallicMS2015;
  // final String solidWhiteMS2015;
  // final String titaniumMetallicMS2015;
  // final String whiteMS2015;
  // final String deepBlueMetallicMS2016;


  // final ImageNetwork imageNetwork;
  CarImage({this.y2008, this.y2009, this.y2010, this.y2011, this.y2015, this.y2016, this.y2017, this.y2018, this.y2019, this.y2020});
  static final List<CarImage> modelSCarsImage = [
    CarImage(
        y2015: ImageNetwork(
          black: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022000.JPG&WIDTH=660",
          blueMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022000.JPG&WIDTH=660",
          deepBlueMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022002.JPG&WIDTH=660",
          greyMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022009.JPG&WIDTH=660",
          midgnightSilver: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022008.JPG&WIDTH=660",
          obsidianBlackMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022010.JPG&WIDTH=660",
          pearlWhiteMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022011.JPG&WIDTH=660",
          redMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022005.JPG&WIDTH=660",
          silverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022007.JPG&WIDTH=660",
          solidWhite: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022012.JPG&WIDTH=660",
          titaniumMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022013.JPG&WIDTH=660",
          white: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022003.JPG&WIDTH=660"
        ),
        y2016: ImageNetwork(
          deepBlueMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022001.JPG&WIDTH=660",
          midgnightSilver: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022002.JPG&WIDTH=660",
          obsidianBlackMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022003.JPG&WIDTH=660",
          pearlWhiteMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022000.JPG&WIDTH=660",
          redMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022004.JPG&WIDTH=660",
          silverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022007.JPG&WIDTH=660",
          solidBlack: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022005.JPG&WIDTH=660",
          solidWhite: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022006.JPG&WIDTH=660",
          titaniumMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022008.JPG&WIDTH=660"
        ),
        y2017: ImageNetwork(
          deepBlueMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022001.JPG&WIDTH=660",
          midgnightSilverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022002.JPG&WIDTH=660",
          obsidianBlackMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022003.JPG&WIDTH=660",
          pearlWhiteMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022000.JPG&WIDTH=660",
          redMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022004.JPG&WIDTH=660",
          silverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022007.JPG&WIDTH=660",
          solidBlack: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022005.JPG&WIDTH=660"        
        ),
        y2018: ImageNetwork(
          deepBlueMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022001.JPG&WIDTH=660",
          midgnightSilverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022002.JPG&WIDTH=660",
          obsidianBlackMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022003.JPG&WIDTH=660",
          pearlWhiteMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022000.JPG&WIDTH=660",
          redMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022004.JPG&WIDTH=660",
          silverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022007.JPG&WIDTH=660",
          solidBlack: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022007.JPG&WIDTH=660"
        ),
        y2019: ImageNetwork(
          deepBlueMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022001.JPG&WIDTH=660",
          midgnightSilverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022002.JPG&WIDTH=660",
          pearlWhiteMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022002.JPG&WIDTH=660",
          redMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022004.JPG&WIDTH=660",
          solidBlack: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022004.JPG&WIDTH=660"
        )
    ),
  ];
  static final List<CarImage> model3CarsImage = [
    CarImage(
      y2017: ImageNetwork(
        deepBlueMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC031B022001.JPG&WIDTH=660",
        midgnightSilverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC031B022002.JPG&WIDTH=660",
        pearlWhiteMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC031B022000.JPG&WIDTH=660",
        redMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC031B022004.JPG&WIDTH=660",
        silverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC031B022003.JPG&WIDTH=660",
        solidBlack: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC031B022003.JPG&WIDTH=660",
      ),
      y2018: ImageNetwork(
        deepBlueMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC80TSC032A022001.JPG&WIDTH=660",
        midgnightSilverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC80TSC032A022002.JPG&WIDTH=660",
        obsidianBlackMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC80TSC032A022006.JPG&WIDTH=660",
        pearlWhiteMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC80TSC032A022000.JPG&WIDTH=660",
        redMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC80TSC032A022004.JPG&WIDTH=660",
        silverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC80TSC032A022003.JPG&WIDTH=660",
        solidBlack: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC80TSC032A022005.JPG&WIDTH=660" 
      ),
      y2019: ImageNetwork(
        deepBlueMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC80TSC032A022001.JPG&WIDTH=660",
        midgnightSilverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC80TSC032A022002.JPG&WIDTH=660",
        pearlWhiteMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC80TSC032A022000.JPG&WIDTH=660",
        redMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC80TSC032A022000.JPG&WIDTH=660",
        solidBlack: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC80TSC032A022000.JPG&WIDTH=660"
      ),
    ),  
  ];
  static final List<CarImage> modelXCarsImage = [
    CarImage(
      y2016: ImageNetwork(
        deepBlueMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022002.JPG&WIDTH=660",
        midgnightSilverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022002.JPG&WIDTH=660",
        obsidianBlackMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022003.JPG&WIDTH=660",
        pearlWhiteMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022000.JPG&WIDTH=660",
        redMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022005.JPG&WIDTH=660",
        silverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022004.JPG&WIDTH=660",
        solidBlack: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022007.JPG&WIDTH=660",
        solidWhite: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022006.JPG&WIDTH=660",
        titaniumMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022006.JPG&WIDTH=660"
      ),
      y2017: ImageNetwork(
        deepBlueMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022001.JPG&WIDTH=660",
        midgnightSilverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022002.JPG&WIDTH=660",
        obsidianBlackMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022003.JPG&WIDTH=660",
        pearlWhiteMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022003.JPG&WIDTH=660",
        redMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022005.JPG&WIDTH=660",
        silverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022004.JPG&WIDTH=660",
        solidBlack: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022004.JPG&WIDTH=660"
      ),
      y2018: ImageNetwork(
        deepBlueMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022001.JPG&WIDTH=660",
        midgnightSilverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022002.JPG&WIDTH=660",
        obsidianBlackMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022003.JPG&WIDTH=660",
        pearlWhiteMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022003.JPG&WIDTH=660",
        redMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022005.JPG&WIDTH=660",
        silverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022004.JPG&WIDTH=660",
        solidBlack: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022007.JPG&WIDTH=660"
      ),
      y2019: ImageNetwork(
        deepBlueMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022001.JPG&WIDTH=660",
        midgnightSilverMetallic: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022000.JPG&WIDTH=660",
        pearlWhiteMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022000.JPG&WIDTH=660",
        redMulticoat: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022005.JPG&WIDTH=660",
        solidBlack: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022007.JPG&WIDTH=660"
      )
    ),
  ];
  static final List<CarImage> modelRoadsterCarsImage = [
    CarImage(
      y2020: ImageNetwork(
        white: "https://cdn.motor1.com/images/mgl/J0yrA/s1/tesla-roadster-live-from-grand-basel.jpg"
      )
    )
  ];
  static final List<CarImage> modelTruckCarsImage = [
    CarImage(
      y2020: ImageNetwork(
        silverMetallic: "https://specials-images.forbesimg.com/imageserve/5dd783c0575d4c00079436d9/960x0.jpg?fit=scale"
      )
    )
  ];
}