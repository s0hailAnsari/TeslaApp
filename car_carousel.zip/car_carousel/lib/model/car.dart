import 'package:car_carousel/model/carImageNetworkMode.dart';
import 'package:car_carousel/model/feature.dart';

class Car {
  final int carId;
  final Feature features;
  final String carImage;
  final List<int> carColor;
  // final List carImageNetwork;
  final List<CarImage> carImageNetwork;


  Car({this.carId, this.features, this.carImage, this.carColor,this.carImageNetwork});
  static final List<Car> modelSCars = [
    Car(
      carId: 1,
      features: Feature(
          releasedYear: 2015, s060: "2.4s", storage: "28 cu ft", range: "273 mi",),
      // carColor: ["Red"
        // 62828],
      // , "Blue", "Grey", "Black"],
      carColor: [0xff1D1B1A,0xff1D2130,0xff102246,0xff303136,0xff0E0E10,0xff212428,0xffE2E2E2,0xff7C0015,0xff94959B,0xffE1E1E1,0xff524D47,0xffE4E4E5],
      carImage: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022003.JPG&WIDTH=660",
      //"assets/images/ts2015.png",      
      carImageNetwork: CarImage.modelSCarsImage,
      // carImageNetwork: [
      //   "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022000.JPG&WIDTH=660",
      //   "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022002.JPG&WIDTH=660",
      //   "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022009.JPG&WIDTH=660",
      //   "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022008.JPG&WIDTH=660",
      //   "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022010.JPG&WIDTH=660",
      //   "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC30TSC021B022011.JPG&WIDTH=660",
      // ]
    ),
    Car(
      carId: 2,
      features: Feature(
          releasedYear: 2016, s060: "2.4s", storage: "28 cu ft", range: "273 mi"),
      carColor: [0xff102246,0xff0E0E10,0xff212428,0xffE2E2E2,0xff7C0015,0xff94959B,0xff040404,0xffE1E1E1,0xff524D47],
      // carColor: ["Red", "Blue", "Grey", "Black"],
      // carImageNetwork: CarImage.model3CarsImage,
      carImage: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022006.JPG&WIDTH=660",
      //"assets/images/ts2016.png",
      carImageNetwork: CarImage.modelSCarsImage,

    ),
    Car(
      carId: 3,
      features: Feature(
          releasedYear: 2017, s060: "2.4s", storage: "28 cu ft", range: "273 mi"),
      carColor: [0xff102246,0xff0E0E10,0xff212428,0xffE2E2E2,0xff7C0015,0xff94959B,0xff040404],
      // carColor: ["Red", "Blue", "Grey", "Black"],
      carImage: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022000.JPG&WIDTH=660",
      carImageNetwork: CarImage.modelSCarsImage,
      //"assets/images/ts2017.png",
    ),
    Car(
      carId: 4,
      features: Feature(
          releasedYear: 2018, s060: "2.4s", storage: "28 cu ft", range: "273 mi"),
      carColor: [0xff102246,0xff0E0E10,0xff212428,0xffE2E2E2,0xff7C0015,0xff94959B,0xff040404],
      // carColor: ["Red", "Blue", "Grey", "Black"],
      carImage: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022000.JPG&WIDTH=660",
      carImageNetwork: CarImage.modelSCarsImage,
      //"assets/images/ts2018.png",
    ),
    Car(
      carId: 5,
      features: Feature(
          releasedYear: 2019, s060: "2.4s", storage: "28 cu ft", range: "273 mi"),
      carColor: [0xff102246,0xff0E0E10,0xffE2E2E2,0xff7C0015,0xff040404],
      // carColor: ["Red", "Blue", "Grey", "Black"],
      carImage: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC024B022000.JPG&WIDTH=660",
      carImageNetwork: CarImage.modelSCarsImage,
      //"assets/images/ts2019.png",
    ),
  ];
  //---------------------------------------------------------------------------------------//
  static final List<Car> model3Cars = [
    Car(
      carId: 1,
      features: Feature(
          releasedYear: 2017, s060: "2.4s", storage: "28 cu ft", range: "273 mi"),
      // carColor: ["Red", "Blue", "Grey", "Black"],
      carColor: [0xff102246,0xff191C20,0xffDFDFD,0xffA1102D,0xff949493,0xff040404],
      carImage: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC70TSC031B022000.JPG&WIDTH=660",//"assets/images/model3.jpg",
      carImageNetwork: CarImage.model3CarsImage,

    ),
    Car(
      carId: 2,
      features: Feature(
          releasedYear: 2018, s060: "2.4s", storage: "28 cu ft", range: "273 mi"),
      carColor: [0xff102246,0xff191C20,0xff0A0B0A,0xffDFDFDF,0xffA1102D,0xff949493,0xff040404],
      // carColor: ["Red", "Blue", "Grey", "Black"],
      carImage: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC80TSC032A022000.JPG&WIDTH=660",//"assets/images/model3.jpg",
      carImageNetwork: CarImage.model3CarsImage,
    ),
    Car(
      carId: 3,
      features: Feature(
          releasedYear: 2019, s060: "2.4s", storage: "28 cu ft", range: "273 mi"),
      // carColor: ["Red", "Blue", "Grey", "Black"],
      carColor: [0xff102246,0xff191C20,0xffCFCFCF,0xffA1102D,0xff040404],
      carImage: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC80TSC032A022000.JPG&WIDTH=660",//"assets/images/model3.jpg",
      carImageNetwork: CarImage.model3CarsImage,
    ),
  ];
  //---------------------------------------------------------------------------------------//
  static final List<Car> modelXCars = [
    Car(
      carId: 1,
      features: Feature(
          releasedYear: 2016, s060: "2.4s", storage: "28 cu ft", range: "273 mi"),
      // carColor: ["Red", "Blue", "Grey", "Black"],
      carColor: [0xff102246,0xff191C20,0xff0A0B0A,0xffDFDFDF,0xffA1102D,0xff949493,0xff040404,0xffE1E1E1,0xff524D47],
      carImage: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022006.JPG&WIDTH=660",//"assets/images/tx2016.png",
      carImageNetwork: CarImage.modelXCarsImage,
    ),
    Car(
      carId: 2,
      features: Feature(
          releasedYear: 2017, s060: "2.4s", storage: "28 cu ft", range: "273 mi"),
      // carColor: ["Red", "Blue", "Grey", "Black"],
      carColor: [0xff102246,0xff191C20,0xff0A0B0A,0xffDFDFDF,0xffA1102D,0xff949493,0xff040404],
      carImage: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022006.JPG&WIDTH=660",//"assets/images/tx2017.png",
      carImageNetwork: CarImage.modelXCarsImage,
    ),
    Car(
      carId: 3,
      features: Feature(
          releasedYear: 2018, s060: "2.4s", storage: "28 cu ft", range: "273 mi"),
      // carColor: ["Red", "Blue", "Grey", "Black"],
      carColor: [0xff102246,0xff191C20,0xff0A0B0A,0xffDFDFDF,0xffA1102D,0xff949493,0xff040404],
      carImage: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022000.JPG&WIDTH=660",//"assets/images/tx2018.png",
      carImageNetwork: CarImage.modelXCarsImage,
    ),
    Car(
      carId: 4,
      features: Feature(
          releasedYear: 2019, s060: "2.4s", storage: "28 cu ft", range: "273 mi"),
      // carColor: ["Red", "Blue", "Grey", "Black"],
      carColor: [0xff102246,0xff191C20,0xffCFCFCF,0xffA1102D,0xff040404],
      carImage: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC60TSS011C022000.JPG&WIDTH=660",//"assets/images/tx2019.png",
      carImageNetwork: CarImage.modelXCarsImage,
    ),
  ];
  //---------------------------------------------------------------------------------------//
  static final List<Car> modelRoadStersCars = [
    Car(
      carId: 1,
      features: Feature(
          releasedYear: 2008, s060: "2.4s", storage: "28 cu ft", range: "273 mi"),
      // carColor: ["Red", "Blue", "Grey", "Black"],
      carColor: [0xffA62C2B],
      carImage: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC00TSC011A01402.JPG&WIDTH=660",//"assets/images/roadster2019.jpg",
      carImageNetwork: CarImage.modelRoadsterCarsImage,
    ),
    Car(
      carId: 2,
      features: Feature(
          releasedYear: 2009, s060: "2.4s", storage: "28 cu ft", range: "273 mi"),
      // carColor: ["Red", "Blue", "Grey", "Black"],
      carColor: [0xffA62C2B],
      carImage: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC00TSC011A01402.JPG&WIDTH=660",//"assets/images/roadster2020.jpg",
      carImageNetwork: CarImage.modelRoadsterCarsImage,
    ),
    Car(
      carId: 3,
      features: Feature(
          releasedYear: 2010, s060: "2.4s", storage: "28 cu ft", range: "273 mi"),
      // carColor: ["Red", "Blue", "Grey", "Black"],
      carColor: [0xffA62C2B],
      carImage: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC00TSC011A01402.JPG&WIDTH=660",//"https://cdcssl.ibsrv.net/autodata/images/?IMG=USB90TSC011A0802.JPG&WIDTH=660",//"assets/images/roadster2020.jpg",
      carImageNetwork: CarImage.modelRoadsterCarsImage,
    ),
    Car(
      carId: 4,
      features: Feature(
          releasedYear: 2011, s060: "2.4s", storage: "28 cu ft", range: "273 mi"),
      // carColor: ["Red", "Blue", "Grey", "Black"],
      carColor: [0xffA62C2B],
      carImage: "https://cdcssl.ibsrv.net/autodata/images/?IMG=USC10TSC011A01402.JPG&WIDTH=660",//"assets/images/roadster2020.jpg",
      carImageNetwork: CarImage.modelRoadsterCarsImage,
    ),
    Car(
      carId: 5,
      features: Feature(
          releasedYear: 2020, s060: "2.4s", storage: "28 cu ft", range: "273 mi"),
      // carColor: ["Red", "Blue", "Grey", "Black"],
      carColor: [0xffA62C2B],
      carImage: "https://cdn.motor1.com/images/mgl/J0yrA/s1/tesla-roadster-live-from-grand-basel.jpg",//"assets/images/roadster2020.jpg",
      carImageNetwork: CarImage.modelRoadsterCarsImage,
    ),
  ];
  //---------------------------------------------------------------------------------------//
  static final List<Car> modelTruckCars = [
    Car(
      carId: 1,
      features: Feature(
          releasedYear: 2020, s060: "2.4s", storage: "28 cu ft", range: "273 mi"),
      // carColor: ["Red", "Blue", "Grey", "Black"],
      carColor: [0xffC4CACE],
      carImage: "https://specials-images.forbesimg.com/imageserve/5dd783c0575d4c00079436d9/960x0.jpg?fit=scale",//"assets/images/cybertruck.jpg",
      carImageNetwork: CarImage.modelTruckCarsImage,
    ),
  ];
}
