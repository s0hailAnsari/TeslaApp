import 'package:car_carousel/model/car.dart';
import 'package:flutter/material.dart';
import 'package:car_carousel/model/homepageModel.dart';

class ShowCarDetails extends StatefulWidget {
  final Car modelYearC;
  final CarModel carModelC;
  // final List<String> cMI;
  ShowCarDetails({Key key, @required this.modelYearC, this.carModelC})
      : super(key: key) {
    // print(this.modelYearC.first);
  }

  @override
  _ShowCarDetailsState createState() => _ShowCarDetailsState();
}

class _ShowCarDetailsState extends State<ShowCarDetails> {
  Text getColorFromValue(val) {
    switch (val) {
      case 0xff1d1b1a:
        {
          return Text("Black");
        }
      case 0xff1d2130:
        {
          return Text("Blue Metallic");
        }
      case 0xff102246:
        {
          return Text("Deep Blue Metallic");
        }
      case 0xff303136:
        {
          return Text("Grey Metallic");
        }
      case 0xff212428:
        {
          return Text("Obsidian Black Metallic");
        }
      case 0xffE2E2E2:
        {
          return Text("Pearl White Multi-Coat");
        }
      case 0xff7C0015:
        {
          return Text("Red Multi-Coat");
        }
      case 0xff94959B:
        {
          return Text("Silver Metallic");
        }
      case 0xff0E0E10:
        {
          return Text("Midnight Silver Metallic");
        }
      case 0xffE1E1E1:
        {
          return Text("Solid White");
        }
      case 0xff524D47:
        {
          return Text("Titanium Metallic");
        }
      case 0xffE4E4E5:
        {
          return Text("White");
        }
      case 0xff040404:
        {
          return Text("Solid Black");
        }

      // case "Grey":
      //   {
      //     return Colors.grey;
      //   }
      // case "Black":
      //   {
      //     return Colors.black;
      //   }
      // case "Blue":
      //   {
      //     return Colors.blue;
      //   }
      //   break;
      default:
        return Text("Color not found");
    }
  }

  @override
  Widget build(BuildContext context) {
    // return Scaffold(
    //   appBar: AppBar(
    //     title :Text(modelYearC.modelYear[1]),
    //   ),
    return Scaffold(
      body: DefaultTabController(
        length: 3,
        child: NestedScrollView(
          headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
            return <Widget>[
              SliverAppBar(
                forceElevated: innerBoxIsScrolled,
                expandedHeight: 200.0,
                floating: true,
                pinned: true,
                flexibleSpace: FlexibleSpaceBar(
                    centerTitle: true,
                    title: Text(
                        widget.carModelC.carModel +
                            " " +
                            widget.modelYearC.features.releasedYear.toString(),
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16.0,
                        )),
                    // background:
                    // Image.asset(
                    //   widget.modelYearC.carImage,
                    //   fit: BoxFit.fill,
                    // )
                    // Image.network()
                    background: Image.network(
                      widget.modelYearC.carImage,
                      fit: BoxFit.fill,
                    )),
              ),
              SliverPersistentHeader(
                delegate: _SliverAppBarDelegate(
                  TabBar(
                    // indicator: BoxDecoration(
                    //   color: Colors.white
                    // ),
                    indicatorWeight: 3.0,
                    labelColor: Colors.black87,
                    unselectedLabelColor: Colors.grey,
                    tabs: [
                      Tab(icon: Icon(Icons.comment), text: "Specifications"),
                      Tab(icon: Icon(Icons.color_lens), text: "Colors"),
                      Tab(icon: Icon(Icons.info), text: "About"),
                    ],
                  ),
                ),
                pinned: true,
              ),
            ];
          },
          body: TabBarView(
            children: [
              // Column(
              //   children: <Widget>[
              //     Padding(
              //       padding: EdgeInsets.only(top: 150.0),
              //     child:
              //     cardDesign(widget.modelYearC.features.range)),
              //     cardDesign(widget.modelYearC.features.s060),
              //     cardDesign(widget.modelYearC.features.storage),
              //     cardDesign(widget.modelYearC.features.storage),
              //     cardDesign(widget.modelYearC.features.storage),
              //     cardDesign(widget.modelYearC.features.storage),
              //     cardDesign(widget.modelYearC.features.storage),
              //     cardDesign(widget.modelYearC.features.storage),
              //     cardDesign(widget.modelYearC.features.storage),
              //     cardDesign(widget.modelYearC.features.storage),
              //     cardDesign(widget.modelYearC.features.storage),
              //     cardDesign(widget.modelYearC.features.storage),
              //     cardDesign(widget.modelYearC.features.storage),
              //     cardDesign(widget.modelYearC.features.storage)
              //   ],
              // ),

              //------------------------------
              ListView.builder(
                  // physics: FixedExtentScrollPhysics(),
                  itemCount: widget.modelYearC.carColor.length,
                  itemBuilder: (context, index) {
                    return Card(
                      child: ListTile(
                          leading: Text(widget.modelYearC.features.range),
                          title: Text(widget.modelYearC.features.range)),

                      //!!!!!!!!!!!!!!!!!!!make another varaible and pass values accordingly
                      // // Text(widget.modelYearC.carColor[index].toString()),
                      // getColorFromValue(
                      //     widget.modelYearC.carColor[index]),
                      // ),
                    );
                  }),
              //-----------------------------

              // Center(child: Text("Range : " + modelYearC.features.range  + "\n0 - 60 : " + modelYearC.features.s060 + "\nStorage : " + modelYearC.features.storage)),
              ListView.builder(
                  // physics: FixedExtentScrollPhysics(),
                  itemCount: widget.modelYearC.carColor.length,
                  itemBuilder: (context, index) {
                    return Card(
                      child: ListTile(
                        leading: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8.0),
                          child: CircleAvatar(
                            radius: 15.0,
                            backgroundColor:
                                // getColorFromValue(
                                // Color(
                                // 0xffc62828),
                                Color(widget.modelYearC.carColor[index]),
                          ),
                        ),
                        title:
                            // Text(widget.modelYearC.carColor[index].toString()),
                            getColorFromValue(
                                widget.modelYearC.carColor[index]),
                      ),
                    );
                  }),

              // Icon(Icons.directions_transit),
              Icon(Icons.directions_transit),
            ],
          ),
        ),
      ),
    );
    // );
  }
}

class _SliverAppBarDelegate extends SliverPersistentHeaderDelegate {
  _SliverAppBarDelegate(this._tabBar);

  final TabBar _tabBar;

  @override
  double get minExtent => _tabBar.preferredSize.height;
  @override
  double get maxExtent => _tabBar.preferredSize.height;

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return new Container(
      color: Colors.white,
      child: _tabBar,
    );
  }

  @override
  bool shouldRebuild(_SliverAppBarDelegate oldDelegate) {
    return false;
  }
}

Padding cardDesign(val) {
  return Padding(
    padding: EdgeInsets.only(top: 10),
    child: SizedBox(
        width: double.infinity,
        child: Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Text(val),
        )),
  );
}
